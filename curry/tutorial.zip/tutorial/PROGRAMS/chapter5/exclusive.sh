#!/bin/sh
cd `(cd \`dirname $0\` ; pwd)`
xterm -e pakcs -l exclusive
