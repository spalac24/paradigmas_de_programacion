-- Main module for KiCS2 REPL kics2i

module Main where
import Basics
import Curry_REPL
main = evalDIO d_C_main
