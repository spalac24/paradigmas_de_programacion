

external_d_C_cover :: Coverable a => a -> ConstStore -> a
external_d_C_cover x _ = cover x