Normally, you can download the syntax highlighting for Curry using
Kate's download mechanism. To do this, go to

    Setting -> Configure Kate ... -> Open/Save -> Modes & Filetypes
    -> Download Highlighting Files ...

In the dialog, just select Curry (it not already selected), click `Install`
and wait for the installation to finish. You must restart Kate for the
installation to take effect.

If that is no option for you, you can also copy the highlighting files
to the directory containing the kate syntax highlighting files.
For instance, this could be:

    cp *.xml ~/.kde/share/apps/katepart/syntax
